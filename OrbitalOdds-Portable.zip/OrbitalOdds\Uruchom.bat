@echo off
cd /d "%~dp0"
start "" "OrbitalOdds.exe"

